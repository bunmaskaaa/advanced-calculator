"""Calculator package."""
